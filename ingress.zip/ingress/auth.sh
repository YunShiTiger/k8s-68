# htpasswd是apache httpd工具包中的工具
# 安装htpasswd
## centos
yum install httpd-tools -y
## ubuntu
apt install apache2-utils -y
# 创建认证文件 QAZwsx@123..   输入密码
htpasswd -c authfile admin
# 查看文件内容
cat authfile


kubectl -n ingress-nginx delete secret basic-auth
kubectl -n ingress-nginx create secret generic basic-auth --from-file=authfile
